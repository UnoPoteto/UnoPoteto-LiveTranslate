# UnoPoteto Live Translate

Public reference version.

This project focuses on:
- Real-time voice translation
- VR communication
- Gaming environments

Translation is not about correctness.
It is about connection.